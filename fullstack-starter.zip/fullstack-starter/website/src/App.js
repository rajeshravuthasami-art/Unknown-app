import React, { useEffect, useState } from 'react';
import axios from 'axios';

// Change this to your deployed backend URL when live
const API_URL = 'http://localhost:5000/api/users';

function App() {
  const [users, setUsers] = useState([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  // Fetch users from backend on page load
  useEffect(() => {
    axios.get(API_URL)
      .then(res => setUsers(res.data))
      .catch(err => console.error(err));
  }, []);

  // Add a new user
  const addUser = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(API_URL, { name, email });
      setUsers([...users, res.data]);
      setName('');
      setEmail('');
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div style={{ maxWidth: 500, margin: '40px auto', fontFamily: 'sans-serif' }}>
      <h1>Users</h1>

      <form onSubmit={addUser} style={{ marginBottom: 20 }}>
        <input
          placeholder="Name"
          value={name}
          onChange={e => setName(e.target.value)}
          required
        />
        <input
          placeholder="Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          required
        />
        <button type="submit">Add User</button>
      </form>

      <ul>
        {users.map(user => (
          <li key={user.id}>{user.name} — {user.email}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
