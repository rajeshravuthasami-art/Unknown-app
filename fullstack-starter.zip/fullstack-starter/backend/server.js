// server.js — entry point for the backend API
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const usersRoutes = require('./routes/users');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());           // allows website (browser) and mobile app to call this API
app.use(express.json());   // parses JSON request bodies

// Routes
app.get('/', (req, res) => {
  res.json({ message: 'API is running' });
});

app.use('/api/users', usersRoutes);

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
